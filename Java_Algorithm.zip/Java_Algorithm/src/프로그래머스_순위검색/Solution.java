package 프로그래머스_순위검색;

public class Solution {

}
